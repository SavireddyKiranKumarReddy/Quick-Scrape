from django.shortcuts import render
import requests

# Helper function to shorten descriptions
def truncate_description(text, char_limit=200):
    if text is None:
        return ""  # Return an empty string if text is None
    if len(text) > char_limit:
        return text[:char_limit].rsplit(' ', 1)[0] + '...'
    return text


def home(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=about%20all%20technologies%20latest%20updates"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('results', [])[:20]
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []

    return render(request, 'news/home.html', {'articles': articles, 'section': 'Top Technology News'})


def artificial_intelligence(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=artificial%20intelligence%20latest%20updates"

    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json() 
        articles = data.get('results', []) 

        # Truncate each article's description
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []
    
    return render(request, 'news/artificial_intelligence.html', {'articles': articles})

def cyber_security_news(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=cyber%20security%20latest%20updates"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('results', [])

        # Truncate each article's description
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []

    return render(request, 'news/cyber_security.html', {'articles': articles, 'section': 'Cyber Security News'})

def machine_learning_news(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=Machine%20learning%20latest%20updates"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('results', [])[:20]  # Limit to 20 articles
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []

    return render(request, 'news/machine_learning.html', {'articles': articles, 'section': 'Machine Learning News'})





def data_science_news(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=data%20science%20latest%20news%20updates"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('results', [])[:20]  # Limit to 20 articles
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []

    return render(request, 'news/data_science.html', {'articles': articles, 'section': 'Data Science News'})


def data_analysis_news(request):
    api_url = "https://newsdata.io/api/1/news?apikey=pub_573534694196402118f34c95d10118aca2fcd&q=data%20analysis%20latest%20updates%20news"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('results', [])[:20]  # Limit to 20 articles
        for article in articles:
            article['description'] = truncate_description(article.get('description', ''), 200)
    else:
        articles = []

    return render(request, 'news/data_analysis.html', {'articles': articles, 'section': 'Data Analysis News'})