from django.contrib import admin
from django.urls import path
from news import views

urlpatterns = [
    path('', views.home, name='home'),  # Home page with top technology news
    path('artificial_intelligence/', views.artificial_intelligence, name='artificial_intelligence'),
    path('cyber-security/', views.cyber_security_news, name='cyber_security_news'),
    path('machine-learning/', views.machine_learning_news, name='machine_learning_news'),
    path('data_science/', views.data_science_news, name='data_science_news'),
    path('data-analysis/', views.data_analysis_news, name='data_analysis_news'),
]